start_list = [7, 5, 3, 3, 2]
new_item = int(input('Введите число'))
start_list.append(new_item)
start_list.sort()
start_list.reverse()
print(start_list)