my_list = ('text', 123, [213, 666], True)
for i in my_list:
    print(type(i))