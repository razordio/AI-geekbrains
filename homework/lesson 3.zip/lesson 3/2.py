def my_user (name, surname, date , city, mail, tel):
    print(f"Имя: {name} ,Фамилия: {surname}, Дата рождения: {date}, Город: {city}, Почта: {mail}, Телефон: {tel}")

my_user(name='Ivan', surname='Ivanov', date='01.10.1987' , city='Toronto', mail=None, tel=None)