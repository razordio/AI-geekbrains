def int_func(text):
    text = text.title()
    return text

my_text = input('Введите строку маленькими буквами: ')
print(int_func(my_text))